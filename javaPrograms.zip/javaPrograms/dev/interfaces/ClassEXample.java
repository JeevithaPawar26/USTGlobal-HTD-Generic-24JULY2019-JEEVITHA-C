package com.dev.interfaces;

public class ClassEXample implements InterfaceExample, InterfaceExample2 {

	@Override
	public void display() {
		System.out.println("display() method ");

	}

	@Override
	public void display1() {
		System.out.println("display()1 method ");

	}

	public static void main(String[] args) {

		ClassEXample c1 = new ClassEXample();
		c1.display();
		InterfaceExample.show();
		c1.display1();
		InterfaceExample2.show1();
		c1.show2();

	}
}
