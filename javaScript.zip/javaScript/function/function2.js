var name = "raj";
function getage(){
    console.log(age);
    var age=10;
    console.log(age);
}