package com.dev.methodOverriding;

public class SuperClass {

	public void display(int num) {
		for (int i = 1; i <= num; i++) {
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		System.out.println("Overriden method");
		SuperClass s1 = new SuperClass();
		s1.display(5);
	}
}
