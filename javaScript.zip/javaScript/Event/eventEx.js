
let buttonElement=document.getElementById('clickButton');//by using on click
buttonElement.onclick=function(){
    alert('hello world');
}
function createPElement(){
    let pElementData=document.createElement('p');//by creating an element
    pElementData.textContent='this is p element';
    document.body.appendChild(pElementData)

}

let alertElement=document.getElementById('alertHi');//add eventlistener
alertElement.addEventListener('click',function(){
alert('good evening')
});
let h1Element=document.createElement('h1');
function showText(){
    let inputElement=document.getElementById('showData');
    console.log(inputElement.value);


    h1Element.textContent=inputElement.value;
    document.body.appendChild(h1Element)
}
