let tableElem=document.getElementById('table1id').innerhtml= `<table border=3px, width=80px, align=center>
                    <tr>
                        <td>Name</td>
                        <td>Age</td>
                        <td>Adress</td>
                        <td>DOB</td>
                        <td>Email</td>
                        <td>Gender</td>
                    </tr> 
                    <tr>
                        <td>King</td> <br>
                        <td>26</td><br>
                        <td>mysuru</td><br>
                        <td>12th&nbspmay</td><br>
                        <td>king@email.com</td><br>
                        <td>male</td><br>
                    </tr> 
                    <tr>
                        <td>Queen</td>
                        <td>19</td>
                        <td>bangalore</td>
                        <td>16th&nbspsept</td>
                        <td>queen@yahoo.com</td>
                        <td>female</td>
                    </tr> </table>`                  
document.write(tableElem);