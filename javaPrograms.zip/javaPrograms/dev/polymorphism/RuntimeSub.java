package com.dev.polymorphism;

public class RuntimeSub extends RunTimeExample {
	@Override
	public void calculate(int a,int b) {
		int result= a-b;
		System.out.println("result of subclass="+result);
	}

	public static void main(String[] args) {
		
		RuntimeSub r2= new RuntimeSub();
		r2.calculate(20, 10);

	}

}
