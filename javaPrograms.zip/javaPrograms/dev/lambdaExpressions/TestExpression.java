package com.dev.lambdaExpressions;

public class TestExpression {

	public static void main(String[] args) {
		System.out.println("(1)  Without using {}------------------>");
		FunctionalInterfae f =()-> System.out.println("Hey im using Lambda Expression");
		f.printValue();
		System.out.println("(2)  With using {}---------------------->");
		FunctionalInterfae f1 =()->{
			for(int i=1;i<=10;i++) {
				System.out.println("i="+i);}
		};
		f1.printValue();
		System.out.println("(3)  We can handle the Expression------>");
		FunctionalInterfae f2 =()->{
			try {
				int num=10/0;
				System.out.println("num="+num);
			}catch(Exception e) {
				System.out.println("Arithmetic Exception ocuured");}
		};	
		f2.printValue(); }}

// Thread-->runnable-->run() method
