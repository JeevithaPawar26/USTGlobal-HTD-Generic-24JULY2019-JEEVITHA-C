package com.dev.casting;

import java.util.Scanner;

public class SampleScanner {

	public static void main(String[] args) {
		Scanner s1=new Scanner(System.in);
		int id;
		//int name;
		System.out.println("Enter the Id");
		int i=s1.nextInt();
		System.out.println("Id :"+i);

	}

}
