//foreach method
var col = ['red','orange','black','blue'];
col.forEach(function(value,index){
if(value.length>3)
console.log("value="+value)
});

console.log("***************************************************");
console.log(name);//error
//var name="chandan";//undefined