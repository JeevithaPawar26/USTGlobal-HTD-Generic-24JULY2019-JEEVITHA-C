var m1='hello';
console.log(m1);
m1=m1+' world';
console.log(m1);
var m2=m1;
console.log(m2);
m1="hi";
console.log(m1);
