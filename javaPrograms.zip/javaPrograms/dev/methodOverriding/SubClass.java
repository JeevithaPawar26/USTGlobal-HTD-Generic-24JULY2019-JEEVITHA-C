package com.dev.methodOverriding;

public class SubClass extends SuperClass {
	@Override
	public void display(int num) {
		for(int i=num;i>=1;i--) {
			System.out.println(i);
		}		
	}
	public static void main(String[] args) {
		
		System.out.println("overriding method");
		SubClass s2=new SubClass();
		s2.display(5);

	}

}
