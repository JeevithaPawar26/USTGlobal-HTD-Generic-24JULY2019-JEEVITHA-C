let empJSON={
    name:"raj",
    age:16,
    hob:['dance','driving']
}
//string interpolation
console.log(`my name is ${empJSON.name}`);//this is java script object
console.log(empJSON);
// we have to convert java script obgect to json string
let jsonObject=JSON.stringify(empJSON);
console.log(jsonObject);
//to convert json object to java script
let javascriptObject=JSON.parse(jsonObject);
console.log(javascriptObject);