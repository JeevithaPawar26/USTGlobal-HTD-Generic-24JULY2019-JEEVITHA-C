package com.dev.collections;

import java.util.HashSet;

public class CollectionEmployee {

	public static void main(String[] args) {
		HashSet<EmployeeDetails> hs= new HashSet<EmployeeDetails>();
		
		EmployeeDetails e1= new EmployeeDetails(); //setting the values
		e1.setName("Raj");
		e1.setId(100);
		e1.setEmail("raj@gmail.com");
		e1.setPassword("rx@3#$");
		
		EmployeeDetails e2= new EmployeeDetails();
		e2.setName("Ram");
		e2.setId(200);
		e2.setEmail("ram@gmail.com");
		e2.setPassword("ra@4#*");
		
		EmployeeDetails e3= new EmployeeDetails();
		e3.setName("Rao");
		e3.setId(300);
		e3.setEmail("rao@gmail.com");
		e3.setPassword("mnox@6#$");
		
		
		System.out.println("add() e1 deatails "+hs.add(e1)); //adding the value to HashSet
		System.out.println("add() e2 deatails "+hs.add(e2));
		System.out.println("add() e3 deatails "+hs.add(e3));
		System.out.println(hs);
		
		e1.setEmail("raj1@gmail.com"); //updating the value
		e2.setEmail("ram1@gmail.com");
		e3.setEmail("rao1@gmail.com");
		System.out.println(hs);
		
	}
}
