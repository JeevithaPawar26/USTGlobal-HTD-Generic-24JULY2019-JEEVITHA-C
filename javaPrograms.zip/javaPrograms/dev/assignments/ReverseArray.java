package com.dev.assignments;

public class ReverseArray {
	
	public static void reverse(int a[]) {
		int[] b=new int[a.length];
		int j=a.length;
		for(int i=0;i<a.length;i++) {
			b[j-1]=a[i];
			j--;	
		}
			
		System.out.println("reversed Array :");
		for(int k=0;k<a.length;k++) {
			System.out.println(+b[k]);
		}
}
	public static void main(String[] args) {
		
		int[] a= {10,20,30,40};
		reverse(a);
		

	}

}
