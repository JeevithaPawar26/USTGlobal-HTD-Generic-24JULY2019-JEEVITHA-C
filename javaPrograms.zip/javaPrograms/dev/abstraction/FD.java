package com.dev.abstraction;

public class FD extends AccountSuper {
	@Override
	public void deposite() {
		System.out.println("deposite any time but fixed deposite");
		
	}

	@Override
	public void withdraw() {
		System.out.println("withdraw only after 10 years");	
	}
	
	public FD() {
		System.out.println("constructor of FD class");	
	}
  
	public static void main(String[] args) {
		FD f1=new FD();
		f1.createAccount();
		f1.deposite();
		f1.withdraw();
	}
}
