package com.dev.assignments;

public class ReverseString {
	
	public static void reverse(String str) {
		String res="";
		for(int i=str.length()-1;i>=0;i--) {
			res=res+str.charAt(i);
		}
		System.out.println("String reverse :"+res);
		//System.out.println(res);	
	}

	public static void main(String[] args) {
		//String str="Hello";
		//reverse(str);
		reverse("Hello");
	}
	
}
