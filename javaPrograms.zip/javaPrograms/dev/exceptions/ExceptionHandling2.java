package com.dev.exceptions;

public class ExceptionHandling2 {

	public static void display() throws Exception,NegativeArraySizeException {
		//StringBuffer s1 = new StringBuffer(10);
		StringBuffer s1 = new StringBuffer(-1);
	}

	public static void main(String[] args) throws Exception,NegativeArraySizeException {
		/*
		 * throws can also used with main method
		 */
		System.out.println("pgm starts.....................");
		display();
		System.out.println("pgm ends.......................");

	}

}
