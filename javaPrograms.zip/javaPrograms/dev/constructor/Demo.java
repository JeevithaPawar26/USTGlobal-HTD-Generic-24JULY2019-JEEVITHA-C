package com.dev.constructor;
import com.dev.methods.MethodExample;

public class Demo {
 
	public static void main(String[] args) {
		int a1=MethodExample.areaOfSquare(5);
		System.out.println("area of sqr="+a1);
		System.out.println("global static variable="+MethodExample.a);
		
	}
}
