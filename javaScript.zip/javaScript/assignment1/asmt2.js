//emp
var emp = {
    ename: 'blake',
    eid: 404,
    company: 'global',
    place: 'india',
    getename : function()
    {
        return this.ename
    },
    
    geteid : function()
    {
        return this.eid;
    }
}
console.log(emp);
var ename =emp.ename;
console.log("ename="+ename);

var eid =emp.eid;
console.log("eid="+eid);

var company =emp.company;
console.log("company="+company);

var place =emp.place;
console.log("place="+place);

//student
var std = {
    sname: 'smith',
    sid: 505,
    school: 'SPV',
    place: 'mysuru',
    getsname : function()
    {
        return this.sname
    },
    
    getsid : function()
    {
        return this.sid;
    }
}
console.log(std);
var sname =std.sname;
console.log("sname="+sname);

var sid =std.sid;
console.log("sid="+sid);

var school =std.school;
console.log("school="+school);

var place =std.place;
console.log("place="+place);

//date
var Date = {
    date: 26,
    month: "MAY",
    year: 1997,
    getdate : function()
    {
        return this.date
    },
    
    getmonth : function()
    {
        return this.month;
    }
}
console.log(Date);
var date =Date.date;
console.log("date="+date);

var month =Date.month;
console.log("month="+month);

var year =Date.year;
console.log("year="+year);

// chocolates

var choco = {
    cname: "dairy milk",
    cprize: 100,
    flavor:"chaco",
    getcname : function()
    {
        return this.cname
    },
    
    getcprize : function()
    {
        return this.cprize;
    }
}
console.log(choco);
var cname =choco.cname;
console.log("cname="+cname);

var cprize =choco.cprize;
console.log("cprize="+cprize);

var flavor =choco.flavor;
console.log("flavor="+flavor);

//shoes
var shoes = {
    brand: "bata",
    sprize: 1000,
    size:6,
    getbrand : function()
    {
        return this.brand
    },
    
    getsprize : function()
    {
        return this.sprize;
    }
}
console.log(shoes);
var brand =shoes.brand;
console.log("brand="+brand);

var sprize =shoes.sprize;
console.log("sprize="+sprize);

var size =shoes.size;
console.log("size="+size);





