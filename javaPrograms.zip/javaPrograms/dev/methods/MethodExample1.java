package com.dev.methods;

public class MethodExample1 {
	
	public static void main(String[] args)
	{
		int res=MethodExample.areaOfSquare(3);
		System.out.println(res);
	}
	
	

}


