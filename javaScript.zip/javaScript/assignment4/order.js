let orderEle=document.getElementById('orderid').innerhtml=
                `<ol type="1">
                <li>english</li>
                <li>kannada</li>
                <li>hindi</li>
                <li>marati</li>
                <li>tamil</li> 
              </ol>
              <ol type="I">
                      <li>java</li>
                      <li>php</li>
                      <li>html</li>
                      <li>css</li>
                      <li>hibernate</li> 
                    </ol>
                    
                    <ul type="square">
                    <li>abc</li>
                    <li>xyz</li>
                    <li>mno</li>
            </ul>
            
            
            <ul type="circle">
                    <li>AAAAA</li>
                    <li>BBBBB</li>
                    <li>CCCCCC</li>
            </ul> `
       
            document.write(orderEle);