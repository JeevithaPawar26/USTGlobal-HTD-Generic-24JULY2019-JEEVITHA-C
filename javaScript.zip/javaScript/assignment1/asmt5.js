var num = ['raj',10,'ram'];
for(var i =0;i<num.length;i++)
{
    console.log(num[i]);
}