//num
var num = new Array(1,2,3,4,5);
console.log("num:"+num);
//color
var color = new Array('blue','green','black');
console.log("color:"+color);
//ID
var ID = new Array(101,202,303);
console.log("ID:"+ID);
//hob
var hob = new Array('dancing','cooking');
console.log("hob:"+hob);
//place
var place = new Array('mysore','banglore');
console.log("place:"+place);


