package com.dev.arrays;

public class CreatingArray {

	public static void main(String[] args) {
		//declaration of an array
		int[] array1; 
		char[] array2;
		byte array3[] ;//another way of declaring an array.

		//creation of an array
		array1= new int[5];
		// add values to the array
		array1[0]=10;
		array1[1]=20;
		array1[2]=30;
		array1[3]=40;
		array1[4]=50;

		array2= new char[5];
		array2[0]='a';
		array2[1]='b';
		array2[2]='c';
		array2[3]='d';
		array2[4]='e';

		array3=new byte[5];
		array3[0]=1;
		array3[1]=2;
		array3[2]=3;
		array3[3]=4;
		array3[4]=5;

		int res1=array3[2]*2;
		System.out.println(res1);

		System.out.println(array2[0]+1);
		System.out.println(array1[3]/2);
		System.out.println(array1[4]-10);
		System.out.println(array2[4]*2);
		System.out.println(array3[3]*4);
		System.out.println(array1[1]%2);

		// Declaration initialization of array in same line
		System.out.println("********initialization and declaration in same line******");

		int[] array4= new int[5];
		int[] array4val= {100,200,300,400};
		System.out.println(array4val[0]);

		//	System.out.println(array4val[5]);  java.lang.ArrayIndexOutOfBoundsException

		System.out.println("**********length of an array*****");
		System.out.println(array4val.length);




	}
}
