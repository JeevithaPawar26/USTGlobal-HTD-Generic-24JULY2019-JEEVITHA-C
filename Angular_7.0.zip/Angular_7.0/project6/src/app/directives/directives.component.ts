import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {
condition=false;
  users=[
    {
    id:10,
    name:'raj',
    city:'mysore'
  },

  {
    id:20,
    name:'ram',
    city:'chennai'
  },
  {
    id:30,
    name:'rao',
    city:'pune'
  },
  {
    id:40,
    name:'king',
    city:'mumbai'
  },
  {
    id:50,
    name:'smith',
    city:'banglore'
  }
]

  constructor() { }
  delete(u1){
    //splice : to remove particular object
    let index=this.users.indexOf(u1);
    this.users.splice(index,1)
    this.condition=true;
  }
close()
{
  this.condition=false;
}
  ngOnInit() {
  }

}
