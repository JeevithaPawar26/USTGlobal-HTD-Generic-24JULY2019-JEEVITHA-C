package com.dev.Access_Specifiers;

public class DemoPublicStatic {
	
	public static int i=10;
	public static double d=22.0;
	
	public static void display() {
		System.out.println("public static display() ");
	}
	
	public static void print() {
		System.out.println("public static print() ");
	}
}
