package com.dev.arrays;

public class ArrayExample3 {

	public static void main(String[] args) {
		int[] a1= {10,20,30,40,50};
		int mid=(a1.length)/2;
		int last =(a1.length-1);
		System.out.println("mid  element of an array="+a1[mid]+"  and having index="+mid);
		System.out.println("last="+a1[last]);
		System.out.println("2nd last="+a1[a1.length-2]);
	}

}
