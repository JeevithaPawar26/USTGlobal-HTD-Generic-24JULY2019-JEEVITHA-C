package com.dev.inheritance;

public class Subclass extends Superclass {
	public Subclass() {
		super(12,"Hello");
	}
	

	public static void main(String[] args) {
		Subclass s1= new Subclass();
		

	}

}
