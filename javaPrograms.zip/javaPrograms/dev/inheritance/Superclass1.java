package com.dev.inheritance;

public class Superclass1 {

	public Superclass1() {
		super();
		System.out.println("no-arg-superclass");
	}

	public Superclass1(int i) {
		System.out.println("int-arg-superclass");
	}

	public Superclass1(String str) {
		System.out.println("string-arg-superclass");
	}

	public Superclass1(String str, int i) {
		System.out.println("string-arg and int-arg -superclass");
	}

	public Superclass1(int i, String str) {
		System.out.println("int-arg and string-arg -superclass");
	}

	public static void main(String[] args) {

	}

}
