console.log(name);
var name='rao';
function getname()
{
    console.log(name);
}

