package com.dev.inheritance;

public class Subclass1 extends Superclass1 {

	public Subclass1() {
		// super(); if we not specify the super statement in
		// zero-argument constructor,compiler will call the super statement.
		System.out.println("no-arg-Subclass");
	}

	public Subclass1(int i) {
		super(12);
		System.out.println("int-arg-Subclass");
	}

	public Subclass1(String str) {
		super("hello");
		System.out.println("string-arg-Subclass");
	}

	public Subclass1(String str, int i) {
		super("wow", 12);
		System.out.println("string-arg and int-arg-Subclass");
	}

	public Subclass1(int i, String str) {
		super(10, "xyz");
		System.out.println("int-arg and string-arg-Subclass");
	}

	public static void main(String[] args) {

		Subclass1 s1 = new Subclass1();
		Subclass1 s2 = new Subclass1(10);
		Subclass1 s3 = new Subclass1("hello");
		Subclass1 s4 = new Subclass1("hey", 200);
		Subclass1 s5 = new Subclass1(400, "hi");

	}

}
