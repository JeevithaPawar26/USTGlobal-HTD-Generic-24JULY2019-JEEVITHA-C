let formEle=document.createElement('form');

let lable1=document.createElement('label');
lable1.textContent='Name:       ';
let f1=formEle.appendChild(lable1);
let text1=document.createElement('input');
let t1=formEle.appendChild(text1);
let brk1=document.createElement('br');
let b1=formEle.appendChild(brk1);

let label2=document.createElement('label');
label2.textContent="Age:";
let f2=formEle.appendChild(label2);
let text2=document.createElement('input');
let t2=formEle.appendChild(text2);
let brk2=document.createElement('br');
let b2=formEle.appendChild(brk2);


let label3=document.createElement('label');
label3.textContent="Address:";
let f3=formEle.appendChild(label3);
let text3=document.createElement('input');
let t3=formEle.appendChild(text3);
let brk3=document.createElement('br');
let b3=formEle.appendChild(brk3);


let label4=document.createElement('label');
label4.textContent="DOB:";
let f4=formEle.appendChild(label4);
let text4=document.createElement('input');
let t4=formEle.appendChild(text4);
let brk4=document.createElement('br');
let b4=formEle.appendChild(brk4);


document.body.appendChild(formEle);