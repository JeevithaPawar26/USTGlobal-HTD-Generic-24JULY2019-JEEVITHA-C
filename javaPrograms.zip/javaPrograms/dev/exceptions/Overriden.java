package com.dev.exceptions;

public @interface Overriden {

}
