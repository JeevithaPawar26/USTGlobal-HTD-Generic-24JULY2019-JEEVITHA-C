package com.dev.interfaces;

import java.io.Serializable;
import java.rmi.Remote;

public interface InterfaceExample2 extends Cloneable,Serializable,Remote{

	public void display1();

	static void show1() {
		System.out.println("show()1 method of interface2");
	}
	
	default void show2() {
		System.out.println("show()2 method of interface2");
	}

}
