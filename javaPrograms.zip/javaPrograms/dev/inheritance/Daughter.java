package com.dev.inheritance;

public class Daughter extends Father {
	static Daughter d1 = new Daughter();

	@Override
	public void printName() {
		String firstName = "Rita dght";
		System.out.println(firstName + " " + d1.firstName + " " + super.lastName);
		super.printName();
	}

	public static void main(String[] args) {
		d1.printName();
		//f1.printName();
		//g1.printName();

	}

}
