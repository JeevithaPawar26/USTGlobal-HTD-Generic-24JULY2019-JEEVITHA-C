package com.dev.abstraction;

public abstract class AbstractionExampleSup {
	
   /*
    * abstract class can have :
    *  1) concrete method (one/many)
    *  2) constructor (one/many)
    *  3) abstract method(one/many)
    */
	
	abstract void display1();
	
	abstract void display2();
	
	public void show() {
		System.out.println("concrete method of superclass");
	}
	
	public AbstractionExampleSup() {
		System.out.println("constructor of superclass");
	}
}
