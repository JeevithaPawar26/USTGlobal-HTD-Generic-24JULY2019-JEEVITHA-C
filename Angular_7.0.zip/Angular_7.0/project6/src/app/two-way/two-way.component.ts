import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-two-way',
  templateUrl: './two-way.component.html',
  styleUrls: ['./two-way.component.css']
})
export class TwoWayComponent implements OnInit {
  // properties
  backgroundCol='red';

  constructor() { }
  // method
  buttonEvent(data){
console.log(data);
  }
  // changeColor(){
  //   if(this.backgroundCol==='red'){
  //     this.backgroundCol='blue';
  //   }
  //   else{
  //     this.backgroundCol='red';
  //   }
  // }
  changeColor(data)
  {
    this.backgroundCol=data;
  }

  ngOnInit(): void {
    console.log('ngoninit imp');
  }

}
