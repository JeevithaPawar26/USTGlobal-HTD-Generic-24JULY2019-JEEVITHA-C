package com.dev.practice1;

public interface EmployeeInterface  {
	
	public EmployeeData putData(String s ,EmployeeData emp);
	public void getData();
	public EmployeeData removeData(String s ,EmployeeData emp);
	

}
