console.log(math.PI);
console.log(math.floor(1.4));
console.log(math.floor(1.5));
console.log(math.ceil(1.4));
console.log(math.ceil(1.5));
console.log(math.round())
console.log(math.pow(2.3))





