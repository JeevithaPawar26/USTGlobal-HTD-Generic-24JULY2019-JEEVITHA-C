package com.dev.packages;

import com.dev.keywords.Sample;

public class TestSample {

	public static void main(String[] args) {
		Sample.display();

	}

}
