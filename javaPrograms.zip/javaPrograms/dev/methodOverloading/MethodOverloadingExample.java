package com.dev.methodOverloading;

public class MethodOverloadingExample {
	
	public void display() {
		System.out.println("zero-arg");
	}
	
	public int display(int i1,int i2) {
		System.out.println("two-int-arg="+i1+" and "+i2);
		return i1+i2;	
	}
	
	static double display(double d1)
	{ 
		System.out.println("double-arg="+d1);
		return d1;
	}
	
	public String display(String s1) {
		System.out.println("string-arg="+s1);
		return s1;
	}
	

	public static void main(String[] args) {
		//non-static
		MethodOverloadingExample m1=new MethodOverloadingExample();
		m1.display();
		m1.display(2,3);
		m1.display("hello world");
		
		//static
		MethodOverloadingExample.display(2.3);
		
		
		
		
		
	}
}
