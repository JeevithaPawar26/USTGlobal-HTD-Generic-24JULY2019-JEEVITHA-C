package com.dev.abstraction;

public class Savings extends AccountSuper {
	
	@Override
	public void deposite() {
		System.out.println("deposite any time");
	}

	@Override
	public void withdraw() {
		System.out.println("withdraw any time");
			
	}

	public static void main(String[] args) {
		
		Savings s1=new Savings();
		s1.createAccount();
		s1.deposite();
		s1.withdraw();

	}
}
