package com.dev.abstraction;

public abstract class AbstractExampleSup1 {
	
	abstract void displayRed();
	abstract void displayGreen();
	
	public AbstractExampleSup1() {
		System.out.println("constructor of super class");
	}
	
	void show() {
		System.out.println("concrete method");
	}
}
