package com.dev.exceptions;

public class Example {
	public static void display() {
		StringBuffer s1 = new StringBuffer(-1);
	}

	public static void main(String[] args) {
		System.out.println("program statrs....................");
		display();
		System.out.println("program ends......................");

	}
}
