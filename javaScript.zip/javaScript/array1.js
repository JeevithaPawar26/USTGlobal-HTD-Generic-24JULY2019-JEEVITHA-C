//add 100 to each price and return new array
var items=[
    {
        name:'book',
        price:95,
    },
    {
        name:'pen',
        price:10,
    },
    {
        name:'box',
        price:100,
    }]
    var items1=items.map(function(items)
    {
        items.price=items.price + 100;
        return items;
    });
    console.log(items1);
