var item=[
    {
        name:'book',
        price:95,
    },
    {
        name:'pen',
        price:10,
    },
    {
        name:'box',
        price:100,
    }]
    var filter1=item.filter(function(item)
    {   
        var item1=item.price>90 && item.name.length>2;
        return item1;
    });
    console.log(filter1);
