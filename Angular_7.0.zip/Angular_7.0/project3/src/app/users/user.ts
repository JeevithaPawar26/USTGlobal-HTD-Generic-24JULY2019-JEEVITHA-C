export class User {
    constructor(
        public name:string,
        public em:string,
        public mob:number,
        public id ? : string ){}
}