let tableEle=document.getElementById('tableid').innerhtml=
   `<table border=1px>
   <thead>
       <tr>
           <th>EmpId</th>
           <th>EmpName</th>
           <th>company</th>
       </tr>
   </thead>
   <tbody>
       <tr>
           <td>100</td>
           <td>scott</td>
           <td>techpark</td>
           
       </tr>
       <tr>
               <td>101</td>
               <td>blake</td>
               <td>infosys</td>
              
           </tr>
           <tr>
                   <td>102</td>
                   <td>king</td>
                   <td>infolite</td>
                   
               </tr>
               <tr>
                       <td>103</td>
                       <td>queen</td>
                       <td>infotech</td>
                      
                   </tr>
               <tr>
                       <td>104</td>
                       <td>mock</td>
                       <td>wipro</td>
                   </tr>
   </tbody>
</table>`;
document.write(tableEle);