package com.dev.strings;

public class StringMethodExample {

	public static void main(String[] args) {
		String str = "Hey! Java String";
		String str1 = "hey! java string";
		int len = str.length();
		System.out.println("Length of string =" + len);
		char[] ch1 = str.toCharArray();
		System.out.println("CharacterArray=" + ch1[10]);
		char ch2 = str.charAt(12);
		System.out.println("charAt=" + ch2);
		boolean b1 = str.equals(str1);
		System.out.println("equals method=" + b1);
		boolean b2=str.equalsIgnoreCase(str1);
		System.out.println("equalsIgnoreCase method=" + b2);
		boolean b3=str.contains("ey J"); //to check the particular character present or not.
		System.out.println("contains()="+b3);
		boolean b4=str.contains("H"); //to check the particular character present or not.
		System.out.println("contains()="+b4);
		String s1=str.replace("Hey", "HEY"); //replace old with new 
		System.out.println("replace()="+s1);
		int i1=str.indexOf('J');
		System.out.println("indexOf()="+i1);
		String s2=str.toUpperCase();
		System.out.println("toUpperCase()="+s2);
		String s3=str.toLowerCase();
		System.out.println("toLowerCase()="+s3);
		String s4=str.substring(3); // index value
		System.out.println("substring()="+s4);
		String s5=str.substring(3, 16);
		System.out.println("substring()="+s5);
		
		//reference variable
		
		String s6= new String("hey whats up");
		System.out.println(s6);
		
		char[] c1= new char[5];
		System.out.println("char []="+c1);

	}

}
