var person = ['rao',10];
for(var val of person)
{
    console.log(val)
}
