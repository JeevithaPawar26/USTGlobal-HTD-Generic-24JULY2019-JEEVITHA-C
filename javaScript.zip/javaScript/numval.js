var num1 = 10;
var num2 = '10';
var num3;
var num4 = null;
var col=['red','blue'];
if(num1==num2)
{
    console.log("equal");
}
else{
    console.log("not equal");
}
if(num1===num2){
    console.log("eql");
}
else
{
    console.log("not eql");
}
console.log("*******************************************************************************************")
var t1=typeof num1;
console.log("t1="+t1);
var t2=typeof num2;
console.log("t2="+t2);
var t3=typeof num1;
console.log("t3="+t3);
var t4=typeof num2;
console.log("t4="+t4);
var t5=typeof col;
console.log("color="+col);

console.log("*******************ternary operator*********************************");

var age=18;
var dis = (age>=18)?"adult":"child";
console.log(dis);

console.log("****************************************************")
var age1 = 21;
var dis1=(age1>21)?"greater":(age1==21)?"equal":"lesser";
console.log(dis1);

console.log("******************************************")
var val=10;
val=val+20;
console.log(val);
var val1=10;
val1+=20;
console.log(val1);

console.log("*******************looping of array********************");
var emp=[
            {
                name: 'abc',
                age: 10,
            },

            {
                name: 'pqr',
                age: 20,
            },
            {
                name: 'xyz',
                age: 30,
            },

        ];

        for(var i=0;i<emp.length;i++)
        {    console.log(emp[i]);
           // console.log(emp[i].name);
           // console.log(emp[i].age);
        }
        








