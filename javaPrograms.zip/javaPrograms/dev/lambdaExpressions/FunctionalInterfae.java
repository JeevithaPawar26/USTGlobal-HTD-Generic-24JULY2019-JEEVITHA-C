/**
 * 
 */
package com.dev.lambdaExpressions;

/**
 * @author MY PC
 * @whenever we use lambda expression we do not need 
 * to override the abstract the method in other class
 *
 */
@FunctionalInterface
public interface FunctionalInterfae {
	public void printValue();
}
