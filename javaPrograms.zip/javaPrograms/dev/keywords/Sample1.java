package com.dev.keywords;

public class Sample1 extends Sample {

	public static void main(String[] args) {
		Sample.display();

	}

}
