package com.dev.polymorphism;

public class Dog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
