import { Injectable, DoCheck } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators' ;
import { AddProduct } from './addproduct';

@Injectable({
  providedIn: 'root'
})
export class AddProductService implements DoCheck {

 url=`https://angular5-7466f.firebaseio.com/`;

 selectedUser: AddProduct ={
   brand:null,
   model:null,
   year_of_release:null,
   cost:null,
   units_sold:null,
   id:null
 };

  constructor(private http: HttpClient) { }
  add= [];

  getData(){
    this.http.get(`${this.url}add.json`).pipe(map(resData=>{
      let addArray=[];
      for(let key in resData){
        addArray.push({...resData[key],id:key});
      }
      return addArray;
    })).subscribe(data => {
      this.add=data;
      console.log(data);
    },err=>{
      console.log(err);
    });
  }
  postData(data){
    return this.http.post(`${this.url}/add.json`,data);
  }
 
  updateData(data){
    // console.log(data.id)
    return this.http.put(`${this.url}add/${data.id}.json`,data)

  }
  deleteData(data)
  {
     return this.http.delete(`${this.url}add/${data.id}.json`);
  }
 ngDoCheck() {
   this.getData();
 }
}