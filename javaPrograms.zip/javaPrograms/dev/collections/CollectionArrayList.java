package com.dev.collections;

import java.util.ArrayList;

import com.dev.constructor.Dog;

public class CollectionArrayList {

	public static void main(String[] args) {
											//size
		ArrayList<Dog> ar=new ArrayList<Dog>(2);
		Dog d1= new Dog();
		d1.setAge(5);
		d1.setBreed("Dober Man");
		d1.setColor("Black");
		d1.setName("Rubi");
		
		Dog d2= new Dog();
		d2.setAge(3);
		d2.setBreed("Dalmation1");
		d2.setColor("Black&White");
		d2.setName("Peru");
		
		Dog d3= new Dog();
		d3.setAge(1);
		d3.setBreed("Dalmation2");
		d3.setColor("Black&Brown");
		d3.setName("Parock");
		
		boolean b1=ar.add(d1);
		boolean b2=ar.add(d2);
		boolean b3=ar.add(d3);
		System.out.println(ar);
		
		ar.trimToSize();
		System.out.println("Size of ArrayList after TrimToset() :"+ar.size());
		
	}

}
