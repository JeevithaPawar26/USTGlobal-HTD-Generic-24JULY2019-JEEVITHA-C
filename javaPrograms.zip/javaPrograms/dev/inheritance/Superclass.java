package com.dev.inheritance;

public class Superclass {
	
	public Superclass() {
		System.out.println("no-arg");
	}
	

	public Superclass(int i) {
		System.out.println("int-arg");
	}
	

	public Superclass(String str) {
		System.out.println("string-arg");
	}
	

	public Superclass(String str, int i) {
		System.out.println("string-arg and int-arg");
	}
	
	public Superclass( int i,String str) {
		System.out.println("int-arg and string-arg");
	}
	
	

	public static void main(String[] args) {
		
	}

}
