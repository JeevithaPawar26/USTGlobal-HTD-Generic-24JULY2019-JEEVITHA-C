sum(20,20);
function sum(num1,num2)
{
    if(num1!=undefined && num2!=undefined)
    {
        sum=num1+num2;
    }
};
console.log("sum="+sum);
console.log("************function expression or anonymous function");
var add = function(x,y)
{
    add= x+y;
    return add;
};
add(10,30);
console.log("sum="+add);
console.log("***********immediately invoke (or self invoke function) function expression");
(function (a,b)
{
var s= a+b;console.log(s);
}(10,20) )
console.log("********************************fat arrow function*********more value*********");
var add1=(p,q)=>{
var a=p+q;
return a;
};
var b=add1(10,20);
console.log(b);
console.log("**********************single line***********no need of return**************************");
var a1 = (p,q)=>p+q;
var sum1=a1(10,30);
console.log(sum1);

