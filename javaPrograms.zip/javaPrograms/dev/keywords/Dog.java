package com.dev.keywords;

//for TreeSet ---> Comparable
public class Dog implements Comparable<Dog>{
	//HashMap we have overridden
	@Override
	public String toString() {
		return "Dog [age=" + age + ", breed=" + breed + ", color=" + color + ", name=" + name + "]";
	}
	private int age;
	private String breed;
	private String color;
	private String name;
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	//To avoid ClassCast Exception
	/*
	 * obj1 compareTo(obj2)
	 * ---> obj1--->this.age
	 * --->  obj2---> d1.age
	 */
	@Override
	public int compareTo(Dog d1){
		return this.age-d1.age;
	}
	

}
