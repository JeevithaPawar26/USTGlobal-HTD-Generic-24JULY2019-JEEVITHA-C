package com.dev.constructor;

public class ConstructorExample {

	public ConstructorExample() {
		System.out.println("zero-args constructor");
	}

	public ConstructorExample(int a) {
		System.out.println("constructor with integer args=" + a);
	}

	public ConstructorExample(String s1) {
		System.out.println("constructor with string args=" + s1);
	}

	public ConstructorExample(String[] s2) {
		System.out.println("constructor with String[]  args =" + s2);
	}

	public ConstructorExample(int x, double y) {
		System.out.println("constructor with two args(int & double) =" + x + " and " + y);
	}

	public ConstructorExample(double y, int x) {
		System.out.println("constructor with two args( double & int ) =" + x + " and " + y);
	}

	public static void main(String[] args) {
		new ConstructorExample();
		new ConstructorExample(100);
		new ConstructorExample("Hello");
		new ConstructorExample("Hey you!!!!!!!!!!!!!!!!!!!!!!!!");
		new ConstructorExample(234, 56.34);
		new ConstructorExample(56.34, 234);
	}
}
