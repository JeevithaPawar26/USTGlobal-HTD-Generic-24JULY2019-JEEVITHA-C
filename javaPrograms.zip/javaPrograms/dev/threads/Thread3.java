package com.dev.threads;

public class Thread3 implements Runnable {

	@Override
	public void run() {
		System.out.println("Thread3 has been started...");
		for(int k=0;k<=10;k++) {
			System.out.println("k="+k);
		}
		System.out.println("Thrad3 ends....");
	}

}











