import { Component} from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent {
  //properties
  redCol=true;
  name='Pawar';
  //classes of bootstrap
  textclasses='bg-success text-white';
  paraghstyle=true;
  padding='50px';
  colspan=2;
  //*************************************************************************** */
  imgURL='https://cdn.pixabay.com/photo/2019/07/03/16/38/light-bulb-4314993__340.jpg';
  constructor() { 
    setTimeout(()=>{
      this.redCol=false;
      this.paraghstyle=false;
    },5000);
  }
}