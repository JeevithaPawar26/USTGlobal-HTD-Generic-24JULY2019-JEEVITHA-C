package com.dev.methods;

public class MethodExample {
	
	public static int  a=10;
	static char c='A';
	static String s="hey Hello";
	static int j=400; //preference check
	 

	public static int areaOfSquare(int side)
	{  
		int j=700; //preference is given to the local variable
		int x=10;
		System.out.println("local variable="+x);
		int area=side*side;
		System.out.println("preference given to the global variables="+j);
		return area;
	}
	
	public int areaOfRec(int len, int width) {
		System.out.println("global variable char ="+c);
		int area1=len*width;
	    //static int area1=len*width;    //(we can not write static)
		//System.out.println("error="+args);  //(local variable cant access in another method)
		return area1;
		
	}

	public static void main(String[] args) {
		//static members
		int side=10;
		int a=areaOfSquare(10);
		System.out.println("Area of square having side "+side+" = "+a);
		System.out.println("global variable string="+s);
		
		//non-static members
		//System.out.println("error"+width);(local variable)
		MethodExample m1 =new MethodExample();
		int a1=m1.areaOfRec(2,3);
		System.out.println("Area of rectangle ="+a1);

	}

}
