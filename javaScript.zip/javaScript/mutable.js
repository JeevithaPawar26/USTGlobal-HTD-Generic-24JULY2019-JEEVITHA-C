var person={
    name:'rao',
    age:22,
}
console.log(person);

person.name='raj';
console.log(person);

var person1=person;
console.log(person);
person1.name='roy';

console.log(person);
console.log(person1);

console.log("*****************************************************************************************************");
var person2={
    name:'rao',
    age:22,
}
console.log(person2);

console.log("***********functions*******************************************");
function first()
{
    console.log("first");
}
function second()
{
    console.log("second");
}
first();
second()

console.log("***********functions***********setTimer****************anonymous****************");
function first1()
{   setTimeout( function()
{
    console.log("first1");
},1000 )
    
}
function second1()
{
    console.log("second1");
}
first1();
second1()



