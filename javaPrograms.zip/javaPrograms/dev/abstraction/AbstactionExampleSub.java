package com.dev.abstraction;

public abstract class AbstactionExampleSub extends  AbstractionExampleSup {
	
	/*If we declare abstract for subclass there
	 *  is no need to override the method present
	 */
	public static void main(String[] args) {
		/*
		 * we can't create the object of abstract class
		 */
		 
	}

}
