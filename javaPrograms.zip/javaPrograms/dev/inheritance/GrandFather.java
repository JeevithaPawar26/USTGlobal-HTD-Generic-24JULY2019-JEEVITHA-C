package com.dev.inheritance;

public class GrandFather {

	String lastName = "kumar";
	String firstName = "Ram grnd";// global variable
	int age = 67;
	static GrandFather g1 = new GrandFather();

	public void printName() {
		// String firstName="ram"; //local variable
		System.out.println(firstName + " " + g1.lastName);
		System.out.println("age=" + g1.age);
	}

	public static void main(String[] args) {
		g1.printName();

	}

}
