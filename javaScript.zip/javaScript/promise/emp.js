let empData=new Promise(function(resolve,reject){
    const emp=[
        {
            name:'raj',
            age:23
        },
        {
            name:'ram',
            age:30
        },
        {
            name:'rao',
            age:45
        }
    ];
    if(10>10)
    {
        reject("failed");
    }
    else{
         resolve(emp);
    }
});
empData.then((data)=>{
    //do not use concatination operator to chk the array data use comma operator we gonna get the the entries present in the array
    //console.log('then block empData=',data);
    return data;
}).catch((error)=> {
    console.log("catch  block="+error);
}).then(function(data1){
    console.log("this is then block2",data1);
});