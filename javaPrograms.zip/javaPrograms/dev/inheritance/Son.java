package com.dev.inheritance;

public class Son extends Father {

	static Son s1 = new Son();

	@Override
	public void printName() {
		String firstName = "rajath son";
		System.out.println(firstName + " " + super.lastName);
		super.printName();
	}

	public static void main(String[] args) {
		s1.printName();
		//f1.printName();
		//g1.printName();

	}

}
