package com.dev.casting;

public class PrimittiveCasting {
	int i=10;
	byte b=(byte) i;
	short s=(short) i;
	int i1=b;
	
	int i2=98;
	char c =(char) i2;
	


}
