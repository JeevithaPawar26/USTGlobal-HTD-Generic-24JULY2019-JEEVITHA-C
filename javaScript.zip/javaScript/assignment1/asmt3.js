//color
var color=['red','green','blue','orange','white'];
console.log("color:"+color);
//hob
var hob=['dance','cook'];
console.log("hob:"+hob);
//name
var name=['raj','ram'];
console.log("name:"+name);
//cake
var cake=['chaco','velvet'];
console.log("cake:"+cake);
//num
var num=[100,200,300,400,600];
console.log("numbers:"+num);

