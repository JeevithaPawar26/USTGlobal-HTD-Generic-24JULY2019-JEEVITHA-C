package com.dev.encapsulation;

public class PetsData {

	public static void main(String[] args) {
		Pets p[]=new Pets[4];
		
		p[0]=new Pets();
		p[0].setAge(1);
		p[0].setColor("black");
		p[0].setName("Dog");
		
		p[1]=new Pets();
		p[1].setAge(2);
		p[1].setColor("brown");
		p[1].setName("rabbit");
		
		p[2]=new Pets();
		p[2].setAge(1);
		p[2].setColor("white");
		p[2].setName("cat");
				
		p[3]=new Pets();
		p[3].setAge(9);
		p[3].setColor("brown& black strip");
		p[3].setName("tiger");
		
		for(int i=0;i<p.length;i++) {
			System.out.println("Age :"+p[i].getAge());
			System.out.println("Color:"+p[i].getColor());
			System.out.println("Name :"+p[i].getName());
			System.out.println("***********************");
		}			
	}

}
