package com.dev.methodOverloading;

public class Calculator {

	public int calculate(int a, int b, int c) {
		int add3 = a + b + c;
		return add3;
	}

	public double calculate(double d1, double d2, double d3) {
		double diff3 = d1 - d2 - d3;
		return diff3;
	}

	public int calculate(int x1, int x2, int x3, int x4) {
		int product4 = x1 * x2 * x3 * x4;
		return product4;
	}

	public void calculate(int p, int q) {
		int add2 = p + q;
		System.out.println("addition of 2-args=" + add2);
	}

	public void calculate(double p, double q) {
		double diff2 = p - q;
		System.out.println("subtraction of 2-args=" + diff2);
	}

	public void calculate(double d1, double d2, int i1, int i2) {
		double add4 = d1 + d2 + i1 + i2;
		System.out.println("addition of 4-args=" + add4);
	}

	public void calculate(double p, double q, double r, double s) {
		double diff4 = p - q - r - s;
		System.out.println("subtraction of 4-args=" + diff4);
	}

	private void calculate(double d1, double d2, int i1) {
		double prod3 = d1 * d2 * i1;
		System.out.println("product of 3-args=" + prod3);

	}

	/*
	 * final method can be overloaded,private method can be overlaoded.
	 */

	final public void calculate(int i1, double d1) {
		double prod2 = i1 * d1;
		System.out.println("product of 2-args=" + prod2);

	}

	public static void main(String[] args) {
		Calculator c1 = new Calculator();

		int add1 = c1.calculate(10, 20, 30);
		System.out.println("addition of 3-args=" + add1);

		double sub1 = c1.calculate(20.2, 5.1, 1.0);
		System.out.println("subtraction of 3-args=" + sub1);

		int prod1 = c1.calculate(1, 2, 3, 2);
		System.out.println("product of 4-args=" + prod1);

		c1.calculate(1, 2);
		c1.calculate(10.1, 2);
		c1.calculate(10.1, 20.1, 1, 2);
		c1.calculate(50.3, 12.1, 0.5, 11.1);
		c1.calculate(3.4, 1.2, 5);
		c1.calculate(10, 2.2);

	}
}
