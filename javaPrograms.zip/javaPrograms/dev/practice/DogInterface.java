package com.dev.practice;

//import com.dev.keywords.Dog;

public interface DogInterface {
	
	public boolean addData(Dog dog);
	public void getData();
	public boolean removeData(Dog dog);

}
