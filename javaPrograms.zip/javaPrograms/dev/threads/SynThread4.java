package com.dev.threads;

public class SynThread4 extends Thread {
	
	PrinterSync p;
	
	public SynThread4(PrinterSync pref) {
		p=pref;
	}	
	@Override
	public void run() {
		/*for(int j=0;j<=10;j++) { System.out.println("j="+j);} */
		try {
			Thread.currentThread().sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		p.printValue(10, "Thread4"); }}






