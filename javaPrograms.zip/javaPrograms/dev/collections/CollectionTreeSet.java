package com.dev.collections;

import java.util.TreeSet;

import com.dev.keywords.Dog;

/*
 * @TreeSet--> arrange data in ascending order with particular selected variable
 * @The class  should implement comparable
 * @We should override compareTo method
 */

public class CollectionTreeSet {

	public static void main(String[] args) {
		TreeSet<Dog> ts=new TreeSet<Dog>();
		Dog d1= new Dog();
		d1.setAge(5);
		d1.setBreed("Dober Man");
		d1.setColor("Black");
		d1.setName("Rubi");
		
		Dog d2= new Dog();
		d2.setAge(3);
		d2.setBreed("Dalmation1");
		d2.setColor("Black&White");
		d2.setName("Peru");
		
		Dog d3= new Dog();
		d3.setAge(1);
		d3.setBreed("Dalmation2");
		d3.setColor("Black&Brown");
		d3.setName("Parock");
		
		boolean b1=ts.add(d1);
		System.out.println(b1);
		System.out.println(ts);
	}
}
