package com.dev.practice;

public class DogMainClass {

	public static void main(String[] args) {
		DogImplementation di =new DogImplementation();
		
		Dog d1 =new Dog();
		d1.setAge(1);
		d1.setBreed("Dobber Man1");
		d1.setName("Spike");
		d1.setColor("Black");
		
		
		Dog d2 =new Dog();
		d2.setAge(3);
		d2.setBreed("Dobber Man2");
		d2.setName("Piko");
		d2.setColor("Brown");
		
		boolean b1 = di.addData(d1);	//call method
		boolean b2 = di.addData(d2);
		System.out.println("d1(add) :"+ b1+"       "+"d2(add) :"+b2);
		
		di.getData(); //call method
		
		boolean b3=di.removeData(d1); //call method
		boolean b4=di.removeData(d2);
		System.out.println("d1(remove) :"+ b3+"       "+"d2(remove) :"+b4);
		
	}

}
