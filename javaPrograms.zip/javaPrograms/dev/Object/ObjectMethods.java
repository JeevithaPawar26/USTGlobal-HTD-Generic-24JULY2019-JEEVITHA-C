package com.dev.Object;

public class ObjectMethods extends Object {

	public static void main(String[] args) {
		Dog d1=new Dog();
		Dog d2=new Dog();
		System.out.println(d1.getClass()); // returns class
		System.out.println(d2.getClass());
		System.out.println("********************************************");
		
		/*System.out.println(d1.clone()); -marker interface
		 * -->throws CloneNotSupportedException;
		 * returns : object
		 */
		
		/*
		 * 1) override hashCode() for equals()
		 * 2) hashCode()--->return type: integer
		 * 3)  equals()---->return type: boolean
		 * 
		 */

	}

}
