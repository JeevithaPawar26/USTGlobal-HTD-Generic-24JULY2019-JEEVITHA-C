package com.dev.packages;

import com.dev.encapsulation.Dog;
//import com.dev.polymorphism.Dog 
/*
 * we can't access the same class name  present in different 
 * package so we go for fully qualified name
 * for specifically for that object
 */
public class Demo {
	Dog d1=new Dog();
	com.dev.polymorphism.Dog  d2=new com.dev.polymorphism.Dog ();
	

}
