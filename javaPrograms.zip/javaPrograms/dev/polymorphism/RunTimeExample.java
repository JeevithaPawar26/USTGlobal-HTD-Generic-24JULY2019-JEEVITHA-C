package com.dev.polymorphism;

public class RunTimeExample {
	
	public void calculate(int a, int b) {
		int result=a+b;
		System.out.println("result of superclass="+result);
	}
public static void main(String[] args) {
	
	RunTimeExample r1=new RunTimeExample();
	r1.calculate(10, 10);
	}
}
