package com.dev.keywords;
import static com.dev.Access_Specifiers.DemoPublicStatic.*;

public class TestImportStatic {
	
	/*
	 * 1) for protected data members extends in TestImportStatic and import directly(if we have different
	 *    access specifier}
	 * 2) if we have same access modifier give static.
	 */

	public static void main(String[] args) {
		System.out.println(i);
		System.out.println(d);
		display();
		print();

	}

}
