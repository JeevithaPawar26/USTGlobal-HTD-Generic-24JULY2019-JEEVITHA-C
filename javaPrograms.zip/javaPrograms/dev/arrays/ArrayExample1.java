package com.dev.arrays;

public class ArrayExample1 {
	public static void main(String[] args) {
		
// index=length-1;
		int[] arr = { 10, 20, 30, 40, 50 };
		int index = 7;
		if (index < arr.length) {
			System.out.println(arr[index]);
		} else {
			System.out.println("ArrayIndexOutOfBoundsException");
		}
	}
}
