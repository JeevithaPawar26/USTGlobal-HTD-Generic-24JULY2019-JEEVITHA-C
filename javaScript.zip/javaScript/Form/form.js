function validateForm(){
    let formData=document.forms[0];
  //  console.log(formData.UserName.value);
  let username=formData.UserName.value;
  let password= formData.pswd.value;
  //let formData=document.forms[0];
  //let password=formData.pswd.value;
  if(username.length>4 && password.length>8)
  {
    console.log("success");
    formData.UserName.style.border='6px solid green';
    formData.pswd.style.border='6px solid green';
    formData.loginsubmit.disabled=false;

  }

 else{
      formData.UserName.style.border='4px solid red';
      formData.pswd.style.border='4px solid red';
    }}
// function validateForm1(){
//     let formData=document.forms[0];
//     let password=formData.pswd.value;
//     if(password.length>8)
//   {
//     console.log("pswd success");
//     formData.pswd.style.border='6px solid green';
//   }

//  else{
//       formData.pswd.style.border='4px solid red';}
// }