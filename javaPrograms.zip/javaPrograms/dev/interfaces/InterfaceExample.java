package com.dev.interfaces;

@FunctionalInterface
public interface InterfaceExample {
	void display();

	static void show() {
		System.out.println("show() method from interface 1");
	}
}
