package com.dev.keywords;

public class Sample {
	
/*
 * 1) variable declare with the Block letter is used to represent it as final
 * 2) final variables can't be re-initialized
 * 3) final methods can't be overridden
 * 4) final class can't inherit but it can be inherited property from super class
 * 5) final class can't be superclass ,but subclass can be final 
 */
	final static int INT=10;
	public final static void display() {
		System.out.println("display method of package com.dev.keywords ");
	}
	
	public static void main(String[] args) {
		System.out.println(INT);
	//	INT=12;( can't to re-initialization)

	}

}
