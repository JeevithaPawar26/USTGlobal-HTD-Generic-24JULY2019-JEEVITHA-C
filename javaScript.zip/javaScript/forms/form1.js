function validate()
{
    let employeeData=document.forms['employeeform'];
    let empPassword=employeeData.pass.value;
    let empCPassword=employeeData.cpass.value;
    //password should not take space
    if(empPassword==='' && empCPassword==='')
    {
        return false;
    }
    if(empPassword===empCPassword)
    {
        alert("sucess");
        return true;
    }
    else
    {
        alert("password not matching");
        return false;
    }
}