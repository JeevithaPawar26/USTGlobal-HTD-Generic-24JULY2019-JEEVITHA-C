package com.dev.constructor;

public class Constructor2 {
	
	public Constructor2() {
		System.out.println("zero-argument");
	}
	
	public Constructor2(double d) {
		System.out.println("one argument="+d);
	}
	
	public Constructor2(int x, char y) {
		System.out.println("two args int and char=" +x+" and "+y);
	}

	public Constructor2(char y, int x) {
		System.out.println("two args char and int=" +y+" and "+x);
	}
	
	public Constructor2(String s, double d) {
		System.out.println("two args string and double=" +s+" and "+d);
	}
	
	public static void main(String[] args) {
		
		Constructor2 c1=new Constructor2();
		System.out.println(c1);
		
		Constructor2 c2=new Constructor2(400,'J');
		System.out.println(c2);
		
		Constructor2 c3=new Constructor2('j',100);
		System.out.println(c3);
		
		Constructor2 c4=new Constructor2(200.12);
		System.out.println(c4);
		
		Constructor2 c5=new Constructor2("Hey you ",200.12);
		System.out.println(c5);
		
		

	}

}
