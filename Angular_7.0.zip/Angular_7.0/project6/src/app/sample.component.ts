import { Component } from "@angular/core";

@Component({
    selector:'app-sample',
    // template:`
    // <h1> Hello World </h1>
    // `,
    // styles:[`h1{background: red; color:black}
    // `]

    // ***********************************creating by link**********************
    templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
 export class SampleComponent {

}