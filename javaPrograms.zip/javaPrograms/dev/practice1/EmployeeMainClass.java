package com.dev.practice1;

public class EmployeeMainClass {

	public static void main(String[] args) {
		
		EmployeeImplementation ei =new EmployeeImplementation(); //non-static
		
		EmployeeData e1=new EmployeeData();
		e1.setId(100);
		e1.setName("Raj");
		e1.setEmail("raj@gmail.com");
		e1.setPassword("#$5ghj$");
		
		EmployeeData e2=new EmployeeData();
		e2.setId(200);
		e2.setName("Ram");
		e2.setEmail("ram@gmail.com");
		e2.setPassword("#$IIb0");
		
		EmployeeData e3=new EmployeeData();
		e3.setId(300);
		e3.setName("Rao");
		e3.setEmail("rao@gmail.com");
		e3.setPassword("rty#$%b0");
		
	  System.out.println("Put data :");
	  ei.putData("1", e1);
	  ei.putData("2", e2);
	  ei.putData("3", e3);
	  System.out.println(ei.hm);
	  
	  System.out.println("Getting the object :");
	  ei.getData();
	  
	  System.out.println("remove Data :");
	  ei.removeData("1", e1);
	  ei.removeData("3", e3);
	  System.out.println(ei.hm);
	}
}
