package com.dev.abstraction;

public class AbstractExampleSub1 extends AbstractExampleSup1{
	
	@Override
	void displayRed() {
		System.out.println("RED");
		
	}

	@Override
	void displayGreen() {
		System.out.println("GREEN");
		
	}
	
	public AbstractExampleSub1() {
		//super() will invoke automatically by the compiler
		System.out.println("constructor of subclass");
	}
	
	

	public static void main(String[] args) {
		
		AbstractExampleSub1 s1=new AbstractExampleSub1();
		s1.displayGreen();
		s1.displayRed();
		s1.show();	
	}
}
