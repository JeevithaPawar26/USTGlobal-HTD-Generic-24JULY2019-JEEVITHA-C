package com.dev.polymorphism;

public class CompileTimeExample {
	
	public void calculate(int a,int b) {
		int result=a+b;	
		System.out.println("Addition="+result);
	}
	
	public void calculate(double a,int b) {
		double result=a-b;	
		System.out.println("Subtraction="+result);
	}
	
	public void calculate(double a,double b) {
		double result=a*b;	
		System.out.println("Multiplication="+result);
	}

	public static void main(String[] args) {
		CompileTimeExample c1=new CompileTimeExample();
		c1.calculate(20, 20);
		c1.calculate(10.1, 5);
		c1.calculate(5.5, 2.0);
	
	}

}
