package com.dev.inheritance;

public class Father extends GrandFather {

	static Father f1 = new Father();
	int age = 40;

	@Override
	public void printName() {
		String firstName = "Raj Fa"; // local variable
		System.out.println(firstName + " " + super.firstName + " " + f1.lastName);
		System.out.println("age=" + f1.age);
		super.printName();
	}

	public static void main(String[] args) {

		f1.printName();
		//g1.printName();

	}

}
