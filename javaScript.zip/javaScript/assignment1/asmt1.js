var d = new Date();
console.log(d);
var b= new Boolean();
console.log(b);
var p= new RegExp("xyz");
console.log(p);
var o= new Object();
console.log(o);
o.website='google';
var a = new Array();
a[0]=100;
a[1]=200;
console.log(a);

