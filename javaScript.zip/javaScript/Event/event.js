function sayHello(){
    alert('hello');
}