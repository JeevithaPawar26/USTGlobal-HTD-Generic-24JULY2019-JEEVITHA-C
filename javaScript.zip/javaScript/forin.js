var person = 
{
    name:'jeev',
    age:22,
};
for(var index in person)
{
    console.log(person[index]);
}