package com.dev.collections;

import java.util.HashSet;

import com.dev.encapsulation.Dog;

public class Collection1 {
	
	/*
	 * C--> Insert/Create----> add()
	 * U--> Read/Retrieve----> println()
	 * R--> Update/Modify----> setAge() /add()
	 * D--> Delete/Drop------> remove()/clear()
	 */

	public static void main(String[] args) {
		HashSet<Dog> hs= new HashSet<Dog>();
		
		Dog d1= new Dog();
		d1.setAge(1);
		d1.setBreed("Dober Man");
		d1.setColor("Black");
		
		Dog d2= new Dog();
		d2.setAge(2);
		d2.setBreed("Dalmation");
		d2.setColor("Black&White");
		
		/*
		 * boolean b5= hs.contains(d1);
		 * System.out.println("contains :"+b5);
		 */
		
		boolean b1=hs.add(d1);
		boolean b2=hs.add(d2);
		for (Dog dog : hs) {
			System.out.println(dog );
		}
		/*System.out.println("o/p of add()---> : "+b1+" , "+b2);
		System.out.println(hs);
		
		System.out.println("size() --->"+hs.size());
		
		boolean b5= hs.contains(d1);
		System.out.println("contains()---> :"+b5);
		
		boolean b3=hs.remove(d1);
		boolean b4=hs.remove(d2);
		System.out.println("o/p of remove()---> : "+b1+" , "+b2);
		System.out.println(hs);
		
		/*
		 * boolean b5= hs.contains(d1);
		 * System.out.println("contains :"+b5);
		 */
	/*	
		System.out.println("size() --->"+hs.size());
		hs.clear();
		*/
}}
//ArrayList



