package com.dev.arrays;

public class ArrayExample2 {

	public static void main(String[] args) {
		int[] arr = { 10, 20, 30, 40, 50 };
		int index = 2;
		if (index < arr.length) {
			System.out.println("valid index is :" + arr[index]);
			for (int i = 0; i <= index; i++) {
				System.out.println(arr[i]);
			}
		} else {
			System.out.println("ArrayIndexOutOfBoundsException");
		}
	}
}
