package com.dev.collections;

import java.util.HashMap;

import com.dev.encapsulation.Dog;

public class CollectionHashMap {

	public static void main(String[] args) {
		
		HashMap<String,Dog> hm =new HashMap<>();
		Dog d1= new Dog();
		d1.setAge(1);
		d1.setBreed("Dober Man");
		d1.setColor("Black");
		d1.setName("jab");
		
		Dog d2= new Dog();
		d2.setAge(2);
		d2.setBreed("Dalmation");
		d2.setColor("Black&White");
		d2.setName("parlo");
		
		 /**
	     * Associates the specified value with the specified key in this map.
	     * If the map previously contained a mapping for the key, the old
	     * value is replaced.
	     *
	     * @param key key with which the specified value is to be associated
	     * @param value value to be associated with the specified key
	     * @return the previous value associated with {@code key}, or
	     *         {@code null} if there was no mapping for {@code key}.
	     *         (A {@code null} return can also indicate that the map
	     *         previously associated {@code null} with {@code key}.)
	     */
		
	/*	hm.put("1",d1); //return type of put()---> object
		Dog ref1=hm.put("1",d1);
		System.out.println(ref1);
	
		hm.put("2",d2);
		Dog ref2=hm.put("2",d2);
		System.out.println(ref2);
		
		*/
		
		hm.put("1",d1);
		hm.put("2",d2);
		System.out.println(hm);
		
		Dog f = hm.remove("2");
		System.out.println(f);
		System.out.println(hm);
		
		System.out.println("contains() d1--->"+hm.containsKey("1"));
		System.out.println("contains() d2--->"+hm.containsKey("2"));
		
		System.out.println("containsValue() d1--->"+hm.containsValue(d1));
		System.out.println("containsValue() d2--->"+hm.containsValue(d2));
	}

}
