package com.dev.abstraction;

public abstract class AccountSuper {
	
	public void createAccount()
	{
		System.out.println("Create your account");
	}
	abstract public void deposite();
	abstract public void withdraw();
}
