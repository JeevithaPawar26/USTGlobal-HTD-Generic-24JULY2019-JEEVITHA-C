import { Component, OnInit } from '@angular/core';
import { AddProductService} from './addproduct.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  
    constructor(private addproductService: AddProductService ,private router: Router) { }
  
    updatecar(car){
      this.addproductService.selectedUser=car;
      this.router.navigateByUrl(`/carsfirebase`);
    }
    deletecar(car){
      this.addproductService.deleteData(car).subscribe(resdata=>{
        console.log(resdata);
        this.addproductService.getData();
  
      })
  
    }
    ngOnInit() {
      this.addproductService.getData();
      // console.log(this.firebaseService.users);
    }
  
  }
  
