package com.dev.assignments;

public class FindArrayElement {
	//size=length
	public static void findSumOfArrayElement(int a[]) {
		int first=a[0];
		int mid=a[(a.length-1)/2];
		int secondLast =a[a.length-2];
		int sum=first+mid+secondLast;
		System.out.println("firstElement="+first);
		System.out.println("midElement="+mid);
		System.out.println("secondLastElement="+secondLast);
		System.out.println("Sum of 1st,mid and 2nd last Element="+sum);	
	}
	public static void main(String[] args) {
		
		int[] a= {10,20,30,40,50,60,70};
		findSumOfArrayElement(a);	
	}
}
