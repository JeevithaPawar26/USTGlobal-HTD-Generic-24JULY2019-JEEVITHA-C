// pass first function then only call the second function.........................
//callback function:passing a function as argument for another function
function first(callback)
{
    setTimeout(function(){
        console.log("first");
        callback();
    },1000);
    console.log("this is first")
}
function second(){
    console.log("second");
}
first(second);