package com.dev.abstraction;

public abstract class SavingAbsChild extends AccountSuper {
	
	public SavingAbsChild() {
		System.out.println("abstract class SavingAbsChild constructor");
	}

	@Override
	public void deposite() {
		System.out.println("deposite any time ");
	
	}
}