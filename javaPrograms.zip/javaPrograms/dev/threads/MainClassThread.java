package com.dev.threads;

public class MainClassThread {
	public static void main(String[] args) {
		System.out.println("main thread as benn started..");
		//create the object of thread2 because start() method is non static
		//new Thread2().start();
		Thread2 t2 =new Thread2();
		t2.setName("Threadname");
		t2.setPriority(2);
		t2.start();	
	/*
	 * Thread3 t3 =new T3();
	 * Thread t= new Thread(3);
	 * t.start();
	 *  (or)
	 */
		new Thread(new Thread3()).start();
		Thread.currentThread().setName("Main thread");
		for(int i=1;i<=10;i++) {
			System.out.println("i="+i); }
		System.out.println("Thread Name2 :"+t2.getName());
		System.out.println("Thread Name 2"+Thread.currentThread().getName());
		System.out.println("Thread2 id="+t2.getId());
	//	System.out.println("Thread3 id"+t3.getId());
		System.out.println("Main thread id"+Thread.currentThread().getId());
		System.out.println("Thread2 priority="+t2.getPriority());
		System.out.println("MainThreadPriority="+Thread.currentThread().getPriority());
		System.out.println("main thread ended...");  }}







