import { Component, OnInit, Input, Output,EventEmitter} from '@angular/core';
//simport { EventEmitter } from 'events';

@Component({
  selector: 'app-bikes-details',
  templateUrl: './bikes-details.component.html',
  styleUrls: ['./bikes-details.component.css']
})
export class BikesDetailsComponent implements OnInit {
  @Input() bikeDetails:any='';
   @Output() bikeEvent= new EventEmitter();
  constructor() { }
  ngOnInit() {
    this.bikeEvent.emit("Information about the bikes");
  }

}
