package com.dev.practice1;

import java.util.HashMap;

public class EmployeeImplementation implements EmployeeInterface  {
	
	HashMap<String,EmployeeData> hm=new HashMap<>();

	@Override
	public EmployeeData putData(String s, EmployeeData emp) {
		
		if(s!=null && emp!=null ) {
			EmployeeData m=	hm.put(s,emp);
			return m ;
		}	
		return null;
	}

	@Override
	public void getData() {
		System.out.println(hm);
		
	}

	@Override
	public EmployeeData removeData(String s, EmployeeData emp) {
			EmployeeData m1= hm.remove(s);
			return m1;	
		
	}
}
