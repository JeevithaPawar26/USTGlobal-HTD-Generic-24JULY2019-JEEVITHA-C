var hob=['cricket','throwball','tennis'];
//isarray return type boolean
var a=Array.isArray(hob);
console.log(a);
//search the element in an array using includes method
 
var i=hob.includes('tennis');
console.log(i);

//add the elements in an array, add at end

hob.push('kabbadi','volleyball');
console.log("hob after pushed:"+hob);

//remove the elements in an arrays,reomved at end
hob.pop();
console.log("after pop:"+hob);

//unshift method: add the at begining
hob.unshift('shopping','cooking');
console.log("unshif:"+hob);

//shif method: removed at the begining
hob.shift();
console.log(hob);

//splice is used to break the num of element.
hob.splice(0,2,'dance','cook')
console.log(hob);
//slice
var hob1=hob.slice(0,1);
console.log("before :"+hob);//not modify
console.log("after:"+hob1);//modified
//join
var h=hob.join('-');
console.log(h);
//instanceof
var i1=hob.indexOf('dance');
console.log(i1);
