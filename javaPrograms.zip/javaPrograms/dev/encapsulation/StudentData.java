package com.dev.encapsulation;

public class StudentData {

	public static void main(String[] args) {
		
		Student s1=new Student();
		s1.setRegNo(10001);
		s1.setName("Jeevitha");
		s1.setEmail("jvrao@gmail.com");
		s1.setPassword("123@gv");
		
		int regNo=s1.getRegNo();
		System.out.println("RegNo:  "+regNo);
		
		String name=s1.getName();
		System.out.println("Name :  "+name);
		
		System.out.println("Email:  "+s1.getEmail());
		
	}
	
}

