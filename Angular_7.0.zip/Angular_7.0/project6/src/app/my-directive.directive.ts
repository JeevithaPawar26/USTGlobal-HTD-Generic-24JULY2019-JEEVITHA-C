import { Directive, ElementRef, HostListener, HostBinding } from '@angular/core';

@Directive({
  selector: '[appMyDirective]'
})
export class MyDirectiveDirective {
  // import the classes using ElementRef it is a class.
  constructor(private elementRef:ElementRef) {
    // properties
    elementRef.nativeElement.style.background='red';
    elementRef.nativeElement.style.color='white';
    elementRef.nativeElement.style.padding='50px';
    elementRef.nativeElement.style.marginTop='70px';
   }


   @HostBinding('style.background') background: string;


  //  decorater
   @HostListener('mouseenter')
   mouseEnter(){
     this.background='orange';
    //  *********************************************************************************
    //  console.log("mouse enter");
    //  alert("mouse enter")
  //  this.elementRef.nativeElement.style.background='yellow';
  //   this.elementRef.nativeElement.style.color='white';
  //   this.elementRef.nativeElement.style.fontSize='300px';
  // ******************************************************************************************
   }
   @HostListener('mouseleave')
   mouseLeave(){
     this.background='purple';
    //  ************************************************************************************
    // this.elementRef.nativeElement.style.background='green';
    // this.elementRef.nativeElement.style.color='blue';
    // this.elementRef.nativeElement.style.fontSize='30px';
    // *************************************************************************************
   }

}
