package com.dev.strings;

public class StringMethods {

	public static void main(String[] args) {
		String str = "Hello World";
		String str1 = "hello World";
		int len = str.length();
		System.out.println("Length of string =" + len);
		char[] ch1 = str.toCharArray();
		System.out.println("CharacterArray=" + ch1[2]);
		char ch2 = str.charAt(6);
		System.out.println("charAt=" + ch2);
		boolean b1 = str.equals(str1);
		System.out.println("equals method=" + b1);
		boolean b2=str.equalsIgnoreCase(str1);
		System.out.println("equalsIgnoreCase method=" + b2);

	}
}
