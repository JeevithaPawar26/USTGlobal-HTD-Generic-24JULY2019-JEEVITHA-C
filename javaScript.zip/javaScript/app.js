/*var todaydate=new Date();
console.log(todaydate);
/*var date1=new Date(2018,10,11,0);
console.log(date1)
var date2=new Date(0);
console.log(date2);
var date3=new Date("October 13,2014 11:13:00");
console.log(date3); */

/*var v1= todaydate.getMonth();
console.log("month:"+v1);
var v2= todaydate.getDay();
console.log("day :"+v2);
*/
