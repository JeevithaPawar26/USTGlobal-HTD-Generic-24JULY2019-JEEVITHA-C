package com.dev.abstraction;

public class SavingConcChild extends SavingAbsChild {

	@Override
	public void deposite() {
		System.out.println("deposite any time ");
		
	}

	@Override
	public void withdraw() {
		System.out.println("withdraw any time any ");
			
	}
public static void main(String[] args) {
		
	SavingConcChild s1=new SavingConcChild();
		s1.createAccount();
		s1.deposite();
		s1.withdraw();
	}
}
