package com.dev.arrays;
public class CreateString {

	public static void main(String[] args) {
		//declaration
		String str1;
		//initialization
		str1="Hello";
		System.out.println("str1 = "+str1);
		
		//declaration and initialization
		String str2="java";
		System.out.println("str2 = "+str2);
		
		// using new keyword
		String str3= new String("Hello Java");
		System.out.println("str3= "+str3);
				
				
		

	}

}
