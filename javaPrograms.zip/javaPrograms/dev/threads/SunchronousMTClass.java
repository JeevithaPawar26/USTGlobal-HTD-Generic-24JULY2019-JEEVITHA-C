package com.dev.threads;

public class SunchronousMTClass {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Synchronous main thrad started..join..");
		PrinterSync p=new PrinterSync();
		/* There will be one printer object it will accessed by thread4 and thread5(Race condition)
		 * Race condition leads to data data is not efficiency */
		//new SynThread4(p).start();
		/* @To get the output in the proper/desired manner
		 * @It will give same output if we Run the code Number of times
		 * @We can comment join() method  
		 * */
		SynThread4 t4= new SynThread4(p);
		t4.start();
		t4.join();
		new SynThread5(p).start();
	/*	for(int i=0;i<=10;i++) { System.out.println("i="+i); } */
		System.out.println("Synchronous main thread terminated..");	} }








