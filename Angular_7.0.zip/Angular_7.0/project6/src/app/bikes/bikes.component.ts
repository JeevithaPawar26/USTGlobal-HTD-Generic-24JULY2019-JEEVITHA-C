import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bikes',
  templateUrl: './bikes.component.html',
  styleUrls: ['./bikes.component.css']
})
export class BikesComponent implements OnInit {
bikeData:any='';
 message:any='';
bikes=[
  {
    brand:'KTM',
    img:'https://cdn.pixabay.com/photo/2017/08/13/13/14/motorcycle-2637088__340.jpg',
    desc:'KTM AG is an Austrian motorcycle and sports car manufacturer owned by KTM Industries AG and Indian manufacturer Bajaj Auto. It was formed in 1992 but traces its foundation to as early as 1934. Today, KTM AG is the parent company of the KTM Group. KTM is known for its off-road motorcycles.'
    
  },
  {
    brand:'Royal Enfield',
    img:'https://cdn.pixabay.com/photo/2017/11/23/04/08/royal-enfield-2972008__340.jpg',
    desc:'Royal Enfield is an Indian motorcycle manufacturing brand with the tag of "the oldest global motorcycle brand in continuous production" manufactured in factories in Chennai in India. Licensed from Royal Enfield by the indigenous Indian Madras Motors, it is now a subsidiary of Eicher Motors Limited, an Indian automaker.'
  },
  {
    brand:'Duke',
    img:'https://cdn.pixabay.com/photo/2019/04/19/10/29/motorcycle-4139052__340.jpg',
    desc:'Powering the 200 Duke is a 199.5cc, DOHC single-cylinder, liquid-cooled, fuel-injected, BSIV-compliant engine that churns out 25.8PS of maximum power at 10,000rpm and a peak torque of 19.2 Nm at 8000rpm, mated to a 6-speed gearbox. ... It comes with a fuel tank capacity of 11 litres.'
  },
  {
    brand:'Apachi',
    img:'https://cdn.pixabay.com/photo/2015/09/08/21/02/superbike-930715__340.jpg',
    desc:'Explore TVS Apache RTR 180 Price in India, Specs, Features, Mileage, TVS Apache RTR 180 Images, TVS News, Apache RTR 180 Review and all other TVS'
  },
  {
    brand:'Harley Davidson',
    img:'https://cdn.pixabay.com/photo/2018/10/26/22/55/harley-davidson-3775527__340.jpg',
    desc:'Harley-Davidson, Inc., H-D, or Harley, is an American motorcycle manufacturer founded in 1903 in Milwaukee, Wisconsin. It was one of two major American motorcycle manufacturers to survive the Great Depression, along with Indian'
  }
]
  constructor() { }
  sendBike(b1){
    this.bikeData=b1;
    console.log(b1);
  }

  ngOnInit() {
  }

}
