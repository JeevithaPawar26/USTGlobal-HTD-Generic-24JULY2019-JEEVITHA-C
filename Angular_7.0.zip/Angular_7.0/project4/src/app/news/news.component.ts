import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';


@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {
  sptNews:any=[];
  usaNews:any=[];

  constructor(private http: HttpClient) { 
    http.get<any>('https://newsapi.org/v2/top-headlines?category=sports&apiKey=3ff678b2f1894f4db798107d57f0e008')
    .subscribe(resData =>
    {
      this.sptNews=resData.articles;
      console.log(this.sptNews);
    })  
  }

  ngOnInit() {
    this.http.get<any>('https://newsapi.org/v2/top-headlines?country=us&apiKey=3ff678b2f1894f4db798107d57f0e008')
    .subscribe(Data =>
    {
      this.usaNews=Data.articles;
      console.log(this.usaNews);
    })
  }

}
